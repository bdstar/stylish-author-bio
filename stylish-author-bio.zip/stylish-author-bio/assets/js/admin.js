jQuery(document).ready(function($) {
	// Init the color picker.
	$('.stylish-author-bio-color-field').wpColorPicker();
});
